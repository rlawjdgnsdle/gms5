function loginboxUI(){
	return '<div id="Login-box">'
	+'	<a id="move_user_login_form" >'
	+'	LOGIN</a>'
	+'	&nbsp;&nbsp;&nbsp;'
	+'	<a id="move_join_form">JOIN</a>'
	+'</div>'
}