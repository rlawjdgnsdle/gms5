function loginUI(){
return '<div id="content-box">'
+'	<h2>사용자 로그인</h2>	'
+'	<form id="loginForm" name="loginForm">'
+'		ID <br>'
+'		<input id="memid" type="text" name="memid" ><br>'
+'		Pass <br>'
+'		<input id="pass" type="text" name="pass"  ><br>'
+'		<input type="hidden" name="action" value="login"/>'
+'		<input id="login_submit" type="button" value="제출"/>'
+'	</form><br>'
+'</div>';

}