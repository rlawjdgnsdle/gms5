package com.gms.web.service.impl;

import java.util.List;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gms.web.brd.BoardVO;
import com.gms.web.cmm.Criteria;
import com.gms.web.cmm.SearchCriteria;
import com.gms.web.domain.ArticleDTO;
import com.gms.web.mapper.BoardMapper;
import com.gms.web.service.BoardService;

import lombok.Data;

@Service
@Data
public class BoardServiceImpl implements BoardService{
	@Autowired
	BoardMapper boardDAO;
	private static final Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);
	@Override
	public void regist(BoardVO board) throws Exception {
		// TODO Auto-generated method stub
		
	}
	@Override
	public BoardVO read(Integer bno) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void modify(BoardVO board) throws Exception {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void remove(Integer bno) throws Exception {
		// TODO Auto-generated method stub
		
	}
	@Override
	public List<BoardVO> listAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<BoardVO> listCriteria(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int listCountCriteria(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public List<BoardVO> listSearchCriteria(SearchCriteria cri) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int listSearchCount(SearchCriteria cri) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public List<String> getAttach(Integer bno) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
}
