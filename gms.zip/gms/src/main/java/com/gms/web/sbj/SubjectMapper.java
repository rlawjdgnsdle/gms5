package com.gms.web.sbj;

import org.springframework.stereotype.Repository;

@Repository
public interface SubjectMapper {
	
}
