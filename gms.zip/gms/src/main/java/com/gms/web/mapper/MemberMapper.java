package com.gms.web.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gms.web.domain.MemberDTO;

@Repository // 기능을 앞으로 가져 올 Mapper
public interface MemberMapper {
	public void post(MemberDTO p);
	public List<?> list(Map<?,?>p);
	public MemberDTO get(MemberDTO p);
	public Integer count(MemberDTO p);
	public void put(MemberDTO p);
	public void delete(MemberDTO p);
		
}
//