package com.gms.web.service;

public interface ImageService {

}
