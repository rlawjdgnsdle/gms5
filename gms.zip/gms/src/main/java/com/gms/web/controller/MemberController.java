package com.gms.web.controller;

import java.util.HashMap;

import java.util.Map;
import java.util.function.Predicate;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.javassist.compiler.ast.Member;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.internal.Function;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.gms.web.cmm.TaeHyung;
import com.gms.web.cmm.Util;
import com.gms.web.domain.MemberDTO;
import com.gms.web.mapper.MemberMapper;

@Controller
@RequestMapping("/member")

@RestController
public class MemberController {
	static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	@Autowired MemberDTO member;
	@Autowired MemberMapper memberMapper;
	@Autowired TaeHyung tae;
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public @ResponseBody Map<String,Object> add(@ModelAttribute("member") MemberDTO member) {
		System.out.println("name is " + member.getMemname());
		Util.Log.accept("MbrCtrl add");
		Map<String,Object> rmap = new HashMap<>();
		Util.Log.accept("넘어온 add 정보 : 아이디 : "+member.getMemid()+"비번 : "+member.getPass());
		String flag = "";
		if(memberMapper.count(member)!=0) {
			flag = "Already exist";
		}else {
			Function<Member,String> f = t ->{
				return "가입완료";
			};
			flag = "####완료####";
		}
		Util.Log.accept(member.toString());
		rmap.put("member", member);
		rmap.put("flag", flag);
		return rmap;
		
	}
	//@RequestMapping mvc 컨트롤러가 다룸 @RestController 잭슨이 다룸 
	// 클라이언트에서 파견된 완전히 다른 객체이다. 
	@RequestMapping("/list")
	public void list() {
	}

	@RequestMapping("/search")
	public void search() {
	}

	@RequestMapping("/retrieve")
	public String retrieve(Model model, @ModelAttribute("user") MemberDTO user) {
		System.out.println("============retrieve========");
		member.setMemid(user.getMemid());
		System.out.println("Mem_id : " + user.getMemid());
		
		return "retrieve:member/retrieve.tiles";
	}

	@RequestMapping("/count")
	public void count() {
	}

	@RequestMapping(value = "/modify", method = RequestMethod.POST)
	public String modify(@ModelAttribute("member") MemberDTO member,
						 @ModelAttribute("user") MemberDTO user) {
		
		System.out.println("member : " + member);
		System.out.println("user : " + user);
		member.setMemid(user.getMemid());
		System.out.println("member : "+ member);
		
		
		user.setPass(member.getPass());
		user.setTeamid(member.getTeamid());
		user.setRoll(member.getRoll());
		
		return "retrieve:member/retrieve.tiles";
	}

	@RequestMapping(value = "/remove", method = RequestMethod.POST)
	public String remove(
			@ModelAttribute("member") MemberDTO member,
			@ModelAttribute("user") MemberDTO user) {
		member.setMemid(user.getMemid());
		System.out.println("user : "+user);
		
		return "redirect:/";
}

	
	@PostMapping("/login")
	public @ResponseBody Map<String,Object> login(@RequestBody MemberDTO member) {					
		logger.info("\n --------- MemberController {} !!--------", "login()");
		Map<String,Object> map = new HashMap<>();
		Util.Log.accept("넘어온 로그인정보 : "+member);
		String pwValid = "WRONG";
		String idValid = "WRONG";
		if(memberMapper.count(member)!=0) {
			idValid = "CORRECT";
			Util.Log.accept("ID유효성체크결과 : "+idValid);
			Function<MemberDTO,MemberDTO> f = (t)->{
				return memberMapper.get(t);
			};
			member = f.apply(member);
			pwValid = (member != null) ? "CORRECT":"WRONG";
			member = (member != null) ? member : new MemberDTO();
			Util.Log.accept("pwValid 유효성체크결과 : "+pwValid);
		}
		Util.Log.accept("ID 유효성체크결과 : "+idValid);
		Util.Log.accept("PW 유효성체크결과 : "+pwValid);
		Util.Log.accept("MBR 유효성체크결과 : "+member.toString());
		map.put("ID", idValid);
		map.put("PW", pwValid);
		map.put("MBR", member);
		return map;//
		}

		

	@RequestMapping("/logout")
	public String logout(SessionStatus sessionStatus) {
		sessionStatus.setComplete();
		logger.info("\n --------- MemberController {} !!--------", "logout()");
		return "redirect:/";
	}

	@RequestMapping("/fileUpload")
	public void fileUpload() {
	}

}
