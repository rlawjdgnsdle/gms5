package com.gms.web.sbj;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sbj")
public class SubjectCtrl {
	
}
