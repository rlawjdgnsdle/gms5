package com.gms.web.sbj;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data @Lazy
public class Exam {
	String sbjSeq, memid, examSeq, term, score; //...…
		 //부모의 키와		   자신의 키 를 가지고 있어야 교차엔터티가 된다.
}
