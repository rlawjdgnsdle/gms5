package com.gms.web.cmm;

public class test {
	public static void main(String[] args) {
		for(int i=0; i<230; i++) {
			System.out.println(
		String.format("%03d", i)+"\r\n\r\n"
		+"==============================================================================");	

	
		}
	}
}
