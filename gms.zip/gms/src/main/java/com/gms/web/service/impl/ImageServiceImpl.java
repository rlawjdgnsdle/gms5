package com.gms.web.service.impl;
import org.springframework.stereotype.Service;
import com.gms.web.service.ImageService;

@Service
public class ImageServiceImpl implements ImageService {
//
}
